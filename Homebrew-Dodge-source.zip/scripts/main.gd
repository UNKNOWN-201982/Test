extends Control

const PLAY_TOP := 150.0
const PLAY_BOTTOM := 650.0
const PLAYER_SIZE := Vector2(42.0, 28.0)
const HAZARD_MIN_SPEED := 190.0
const HAZARD_MAX_SPEED := 330.0

var font: Font
var state := "title"
var player := Vector2(640.0, 570.0)
var hazards: Array[Dictionary] = []
var spawn_timer := 0.0
var elapsed := 0.0
var score := 0
var best_score := 0
var last_score := 0
var paused := false
var rng := RandomNumberGenerator.new()
var title_label: Label
var hint_label: Label
var status_label: Label
var score_label: Label
var footer_label: Label

func _ready() -> void:
    set_process_input(true)
    set_process_unhandled_input(true)
    font = ThemeDB.fallback_font
    rng.randomize()
    _build_ui()
    _show_title()
    queue_redraw()

func _build_ui() -> void:
    title_label = _label(64, Color("e9f7ff"), Vector2(0, 54), Vector2(1280, 90))
    hint_label = _label(22, Color("9fc7dc"), Vector2(0, 244), Vector2(1280, 44))
    status_label = _label(20, Color("68e0ef"), Vector2(0, 314), Vector2(1280, 40))
    score_label = _label(28, Color("e9f7ff"), Vector2(42, 28), Vector2(1196, 44))
    score_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
    footer_label = _label(16, Color("70899a"), Vector2(0, 670), Vector2(1280, 28))

func _label(size: int, color: Color, position: Vector2, rect_size: Vector2) -> Label:
    var label := Label.new()
    label.add_theme_font_override("font", font)
    label.add_theme_font_size_override("font_size", size)
    label.add_theme_color_override("font_color", color)
    label.position = position
    label.size = rect_size
    label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(label)
    return label

func _show_title() -> void:
    state = "title"
    paused = false
    hazards.clear()
    title_label.text = "HOMEBREW DODGE"
    hint_label.text = "A tiny offline controller demo"
    status_label.text = "PRESS ENTER / SPACE / GAMEPAD A TO START"
    score_label.text = "BEST  %05d" % best_score
    footer_label.text = "MOVE: A / D  or  LEFT / RIGHT  •  PAUSE: ESC / START"
    queue_redraw()

func _start_game() -> void:
    state = "playing"
    paused = false
    player = Vector2(640.0, 570.0)
    hazards.clear()
    spawn_timer = 0.15
    elapsed = 0.0
    score = 0
    title_label.text = ""
    hint_label.text = ""
    status_label.text = ""
    footer_label.text = "A / D or LEFT / RIGHT to move   •   ESC / START to pause"
    queue_redraw()

func _game_over() -> void:
    state = "gameover"
    last_score = score
    best_score = max(best_score, score)
    title_label.text = "RUN OVER"
    hint_label.text = "You survived %0.1f seconds" % elapsed
    status_label.text = "PRESS ENTER / SPACE / GAMEPAD A TO TRY AGAIN"
    score_label.text = "SCORE  %05d        BEST  %05d" % [last_score, best_score]
    footer_label.text = "The hazards get faster the longer you survive."
    queue_redraw()

func _process(delta: float) -> void:
    if state != "playing" or paused:
        queue_redraw()
        return
    elapsed += delta
    score = int(elapsed * 10.0)
    spawn_timer -= delta
    if spawn_timer <= 0.0:
        _spawn_hazard()
        spawn_timer = max(0.22, 0.72 - elapsed * 0.012)
    var axis := Input.get_axis("move_left", "move_right")
    if Input.get_connected_joypads().has(0):
        axis += Input.get_joy_axis(0, JOY_AXIS_LEFT_X)
    player.x = clamp(player.x + clamp(axis, -1.0, 1.0) * 430.0 * delta, 90.0, 1190.0)
    for hazard in hazards:
        hazard["position"].y += hazard["speed"] * delta
        if _collides(hazard["position"], hazard["radius"]):
            _game_over()
            return
        hazard["life"] -= delta
    hazards = hazards.filter(func(h: Dictionary) -> bool: return h["life"] > 0.0 and h["position"].y < 700.0)
    score_label.text = "SCORE  %05d        TIME  %04.1f" % [score, elapsed]
    queue_redraw()

func _spawn_hazard() -> void:
    var radius := rng.randf_range(12.0, 24.0)
    hazards.append({
        "position": Vector2(rng.randf_range(100.0, 1180.0), PLAY_TOP - 35.0),
        "radius": radius,
        "speed": rng.randf_range(HAZARD_MIN_SPEED, HAZARD_MAX_SPEED) + elapsed * 3.0,
        "life": 5.0
    })

func _collides(point: Vector2, radius: float) -> bool:
    var closest := Vector2(clamp(point.x, player.x - PLAYER_SIZE.x * 0.5, player.x + PLAYER_SIZE.x * 0.5), clamp(point.y, player.y - PLAYER_SIZE.y * 0.5, player.y + PLAYER_SIZE.y * 0.5))
    return closest.distance_to(point) < radius

func _unhandled_input(event: InputEvent) -> void:
    if event.is_action_pressed("pause") or (event is InputEventJoypadButton and event.button_index == JOY_BUTTON_START and event.pressed):
        if state == "playing":
            paused = not paused
            queue_redraw()
            get_viewport().set_input_as_handled()
            return
    if event.is_action_pressed("ui_accept") or (event is InputEventJoypadButton and event.button_index == JOY_BUTTON_A and event.pressed):
        if state == "title" or state == "gameover":
            _start_game()
        elif paused:
            paused = false
        get_viewport().set_input_as_handled()

func _draw() -> void:
    draw_rect(Rect2(Vector2.ZERO, size), Color("08121c"))
    for y in range(PLAY_TOP, 660, 42):
        draw_line(Vector2(70, y), Vector2(1210, y), Color(0.12, 0.26, 0.34, 0.30), 1.0)
    for x in range(90, 1210, 110):
        draw_line(Vector2(x, PLAY_TOP), Vector2(x, 650), Color(0.08, 0.22, 0.30, 0.24), 1.0)
    draw_line(Vector2(70, PLAY_TOP), Vector2(1210, PLAY_TOP), Color("2e6f84"), 2.0)
    draw_line(Vector2(70, PLAY_BOTTOM), Vector2(1210, PLAY_BOTTOM), Color("2e6f84"), 2.0)
    if state == "playing" or state == "gameover":
        _draw_ship(player)
        for hazard in hazards:
            _draw_hazard(hazard["position"], hazard["radius"])
    if state == "title":
        draw_circle(Vector2(640, 468), 48.0, Color(0.08, 0.55, 0.72, 0.14))
        draw_circle(Vector2(640, 468), 24.0, Color("42d7e7"))
    if paused:
        draw_rect(Rect2(0, 0, size.x, size.y), Color(0.02, 0.05, 0.08, 0.74))
        draw_string(font, Vector2(0, 360), "PAUSED", HORIZONTAL_ALIGNMENT_CENTER, 1280, 52, Color("e9f7ff"))
        draw_string(font, Vector2(0, 408), "PRESS ESC / START TO RESUME", HORIZONTAL_ALIGNMENT_CENTER, 1280, 18, Color("9fc7dc"))

func _draw_ship(pos: Vector2) -> void:
    var points := PackedVector2Array([pos + Vector2(0, -18), pos + Vector2(24, 15), pos + Vector2(0, 8), pos + Vector2(-24, 15)])
    var outline := PackedVector2Array([points[0], points[1], points[2], points[3], points[0]])
    draw_colored_polygon(points, Color("42d7e7"))
    draw_polyline(outline, Color("d9fbff"), 2.0)
    draw_circle(pos + Vector2(0, 2), 5.0, Color("08121c"))

func _draw_hazard(pos: Vector2, radius: float) -> void:
    draw_circle(pos, radius + 5.0, Color(0.88, 0.28, 0.35, 0.16))
    draw_circle(pos, radius, Color("ef5664"))
    draw_line(pos - Vector2(radius * 0.55, radius * 0.55), pos + Vector2(radius * 0.55, radius * 0.55), Color("ffd6d8"), 2.0)
    draw_line(pos + Vector2(radius * 0.55, -radius * 0.55), pos - Vector2(radius * 0.55, -radius * 0.55), Color("ffd6d8"), 2.0)
